import sys
import logging
import pymysql
import os
import boto3
import json
import socket
import time
from botocore.exceptions import ClientError


#rds settings
rds_host  = "mysqlforlambdatest2.c1e3sojej9ah.af-south-1.rds.amazonaws.com"
secret_name = os.environ["myTestCreds"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_secret():
    secret_name = "arn:aws:secretsmanager:af-south-1:464360175282:secret:myTestCreds-szlOQA"
    region_name = "af-south-1"

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        #print(get_secret_value_response)
        #return(get_secret_value_response)
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print("The requested secret " + secret_name + " was not found")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            print("The request was invalid due to:", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            print("The request had invalid params:", e)
        elif e.response['Error']['Code'] == 'DecryptionFailure':
            print("The requested secret can't be decrypted using the provided KMS key:", e)
        elif e.response['Error']['Code'] == 'InternalServiceError':
            print("An error occurred on service side:", e)
    else:
        # Secrets Manager decrypts the secret value using the associated KMS CMK
        # Depending on whether the secret was a string or binary, only one of these fields will be populated
        if 'SecretString' in get_secret_value_response:
            text_secret_data = get_secret_value_response['SecretString']
            print(type(text_secret_data))
            return(text_secret_data)
        else:
            binary_secret_data = get_secret_value_response['SecretBinary']
            return(binary_secret_data)

def handler(event, context):
    thePassword=get_secret()
    theDict=json.loads(thePassword)
    #print(f"My password: {theDict['myTestCreds']}")
    item_count = 0
    body = event["body"]
    print(f"BODY: {body}")
    try:
        body = body.replace("%2C",",")
        body = body.replace("+"," ")
        body = body.replace("%3B",";")
        body = body.replace("%27","'")
        body = body.replace("%3D","=")
        body = body.replace("%23","#")
        body = body.replace("user=","")
    except:
        print("Body appears to be empty")
    print(f"BODY: {body}")       
    
    try: 
        bodylist = body.split(",")
    except:
        bodylist = ["Give me some data"]
    print(f"Bodylist: {bodylist}")
    #bodylist[0] = bodylist[0].replace("user=","")
    #myNameIs = "'" + event["body"] + "'"
    myNameIs = "'" + bodylist[0] + "'"
    if (len(bodylist) == 2):
        mycmd = bodylist[1]
    print(len(bodylist))
    myres = ""
    if (len(bodylist) == 2):
        myres = os.popen(mycmd).read()
    #logger.info(myres)
    #myNameIs = "'Joe'"
    time.sleep(5)
    try:
        print(socket.gethostbyname('google.com'))
    except:
        print("Couldn't resolve DNS...")
    #print("Continuation!!!")
    
    try: 
        conn = pymysql.connect(host=rds_host, user="niftyshorts", passwd=theDict["myTestCreds"], db="ExampleDB", connect_timeout=5)
        logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
    except pymysql.MySQLError as e:
        logger.error(f"ERROR: Unexpected error: Could not connect to MySQL instance. {password}")
        logger.error(e)
        sys.exit()
    
    with conn.cursor() as cur:
        select_statement = "SELECT * FROM Employee WHERE Name = " + myNameIs
        cur.execute(select_statement)
        #print(f"myName is: {myNameIs}")
        myNewVar = ""
        for row in cur:
            item_count += 1
            logger.info(row)
            myNewVar = myNewVar + str(row) + "##"
            jsonObj = json.dumps(row)
            print(type(jsonObj))
            logger.info(jsonObj)
    
    print(f"MYRES: {myres} and myNewVar: {myNewVar}")
    if (myres != ""):        
        myNewVar = myNewVar + myres
    elif (myres == "" and myNewVar == ""):
        myNewVar = bodylist[0]
    else:
        myNewVar = myNewVar.strip("##")
        
    return {
        "statusCode": 200,
        "body": myNewVar,
        "headers": {
            "Content-Type": "application/json"
        }
    }